Create Intro to R and Intro to Plotting functions
Anders worked on Intro to R and Kunal worked on Intro to Plotting, Samuel worked on both with small changes and bug fixes
Resources: Google and R official website